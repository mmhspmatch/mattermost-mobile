package bulenda;

import static org.junit.jupiter.api.Assertions.*;

import java.util.stream.IntStream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

public class DynamicTest {
	
	NumberChecker checker = new NumberChecker();
	
	@ParameterizedTest
	@MethodSource("generateEvenNumbers")
	void testIsEvenRange(int number) {
		System.out.println("Test mit " + number);
		assertTrue(checker.isEven(number));
	}
	
	static IntStream generateEvenNumbers() {
		return IntStream.iterate(0, i-> i+2).limit(20);
	}

}
