package bulenda;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

/*
 * Um die Verwendung der Tags zu testen, ist es am einfachsten
 * mvn clean test -Dgroups="Development" 
 * oder mvn clean test -DexcludedGroups="Development"aufzurufen
 *  
 */
@Tag("Development")
public class TagTest {
	
	@Test
    void testOne() {
        System.out.println("Test eins");
    }

}
