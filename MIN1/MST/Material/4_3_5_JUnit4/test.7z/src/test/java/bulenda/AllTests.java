package bulenda;


import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectClasses({AppTest.class,DynamicTest.class})
public class AllTests{
}


