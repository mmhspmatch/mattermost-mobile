package demopackage;

public interface MySpecialTests {

}
