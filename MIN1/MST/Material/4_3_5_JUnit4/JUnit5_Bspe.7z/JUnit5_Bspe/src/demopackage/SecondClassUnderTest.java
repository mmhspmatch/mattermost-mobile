package demopackage;

public class SecondClassUnderTest {
	
	String greeting(String name) {
		return "Hello "+name;
	}

}
