package bulenda;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
		System.out.println( "Hello World!" );
		boolean d = (a & b) ^ (a || b) | a;  
    }
}
