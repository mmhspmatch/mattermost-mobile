package example;

public class Contracts {
	public static void main(String[] args) {
		System.out.println(new Numbers().add(10, 5));
	}
}
